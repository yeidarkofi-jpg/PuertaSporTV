# Puerta SporTV — Proyecto Android Nativo Kotlin

## ⚡ Cómo obtener tu APK desde el celular (sin PC)

### Paso 1 — Crear cuenta en GitHub
1. Abre [github.com](https://github.com) en tu celular
2. Crea una cuenta gratis si no tienes

### Paso 2 — Crear repositorio
1. Toca el botón `+` → **New repository**
2. Nombre: `PuertaSporTV`
3. Privado o público (da igual)
4. **NO** marques "Add README"
5. Toca **Create repository**

### Paso 3 — Subir el proyecto
**Opción A — GitHub App (recomendada):**
1. Instala la app **GitHub** desde Play Store
2. Abre el repo recién creado
3. Toca el botón `+` → **Upload files**
4. Sube todos los archivos del ZIP que descargaste

**Opción B — Desde el navegador:**
1. En la página del repo vacío, toca **"uploading an existing file"**
2. Sube los archivos uno a uno o en ZIP

### Paso 4 — Activar GitHub Actions
1. En el repo, toca la pestaña **Actions**
2. Si te pide activar workflows, acepta
3. El workflow `Build APK` se ejecutará automáticamente

### Paso 5 — Descargar el APK
1. En la pestaña **Actions**, espera ~8-12 minutos
2. Toca la ejecución completada ✅
3. En la sección **Artifacts**, toca **PuertaSporTV-debug**
4. Descarga el ZIP → extrae el APK
5. Instala en tu dispositivo (debes tener activado "Instalar apps desconocidas")

---

## 📁 Estructura del proyecto

```
PuertaSporTV/
├── .github/workflows/build.yml    ← Compila el APK en la nube
├── app/
│   ├── build.gradle.kts           ← Dependencias
│   ├── src/main/
│   │   ├── AndroidManifest.xml
│   │   ├── java/com/yeidark/sportv/
│   │   │   ├── PuertaSporTVApp.kt
│   │   │   ├── data/              ← Modelos, parsers, repositorios
│   │   │   ├── di/                ← Hilt DI
│   │   │   ├── ui/                ← Fragments, ViewModels
│   │   │   └── util/              ← Utilidades
│   │   └── res/                   ← Layouts XML, temas, recursos
├── build.gradle.kts
└── settings.gradle.kts
```

## 🎨 Características incluidas
- ✅ 4 fuentes de agenda (S1/S2/S3/Stock)
- ✅ Reproductor nativo ExoPlayer/Media3
- ✅ Extractor de streams HLS automático
- ✅ 30+ canales de TV con multi-servidor
- ✅ 10 temas de color
- ✅ Modo TV + navegación D-pad
- ✅ Picture in Picture nativo
- ✅ Notificaciones de partidos
- ✅ Play Integrity API
- ✅ Pantalla completa automática

## 🔧 Paquete
`com.yeidark.sportv`
