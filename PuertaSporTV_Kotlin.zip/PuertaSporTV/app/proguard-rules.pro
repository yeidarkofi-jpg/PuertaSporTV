# Jsoup
-keep public class org.jsoup.** { *; }

# OkHttp
-dontwarn okhttp3.**
-keep class okhttp3.** { *; }

# Media3 / ExoPlayer
-keep class com.google.android.exoplayer2.** { *; }
-keep class androidx.media3.** { *; }

# Hilt
-keep class dagger.hilt.** { *; }
-keep @dagger.hilt.android.HiltAndroidApp class * { *; }
-keep @dagger.hilt.InstallIn class * { *; }

# Data classes (Room + Parcelize)
-keep class com.yeidark.sportv.data.model.** { *; }
-keep class com.yeidark.sportv.domain.model.** { *; }

# Play Integrity
-keep class com.google.android.play.core.integrity.** { *; }

# Navigation SafeArgs
-keep class com.yeidark.sportv.ui.**.directions** { *; }
-keep class com.yeidark.sportv.ui.**.args** { *; }
