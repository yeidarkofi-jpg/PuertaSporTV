package com.yeidark.sportv.ui.player

import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.net.toUri
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.navigation.fragment.findNavController
import com.google.android.material.chip.Chip
import com.yeidark.sportv.R
import com.yeidark.sportv.data.model.Match
import com.yeidark.sportv.databinding.FragmentPlayerBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@UnstableApi
@AndroidEntryPoint
class PlayerFragment : Fragment() {

    private var _binding: FragmentPlayerBinding? = null
    private val binding get() = _binding!!
    private val viewModel: PlayerViewModel by viewModels()
    private var player: ExoPlayer? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, saved: Bundle?): View {
        _binding = FragmentPlayerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val match = arguments?.getParcelable<Match>("matchJson")
        val serverIndex = arguments?.getInt("serverIndex", 0) ?: 0

        if (match == null) { findNavController().popBackStack(); return }

        binding.tvPlayerTitle.text = match.name
        buildServerChips(match)

        initPlayer()
        viewModel.loadMatch(match, serverIndex)

        binding.btnBack.setOnClickListener { findNavController().popBackStack() }
        binding.btnFullscreen.setOnClickListener { toggleFullscreen() }
        binding.btnPip.setOnClickListener { enterPip() }
        binding.btnRetry.setOnClickListener { viewModel.retry() }

        observeState()
    }

    private fun initPlayer() {
        player = ExoPlayer.Builder(requireContext()).build().also { exo ->
            binding.playerView.player = exo
            exo.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    when (state) {
                        Player.STATE_BUFFERING -> showLoader(true)
                        Player.STATE_READY -> {
                            showLoader(false)
                            if (viewModel.autoFullscreen) enterFullscreen()
                        }
                        Player.STATE_ENDED -> Toast.makeText(context, "Transmisión finalizada", Toast.LENGTH_SHORT).show()
                        Player.STATE_IDLE -> {}
                    }
                }
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    showLoader(false)
                    binding.errorGroup.visibility = View.VISIBLE
                    binding.tvPlayerError.text = "Error: ${error.message ?: "No se pudo conectar"}"
                }
            })
        }
    }

    private fun observeState() {
        lifecycleScope.launch {
            viewModel.streamState.collect { state ->
                when (state) {
                    is StreamState.Idle    -> {}
                    is StreamState.Loading -> { showLoader(true); binding.errorGroup.visibility = View.GONE }
                    is StreamState.Direct  -> playDirect(state.hlsUrl)
                    is StreamState.Embed   -> openEmbed(state.embedUrl)
                    is StreamState.Error   -> {
                        showLoader(false)
                        binding.errorGroup.visibility = View.VISIBLE
                        binding.tvPlayerError.text = state.msg
                    }
                }
            }
        }
    }

    private fun playDirect(url: String) {
        showLoader(false)
        binding.playerView.visibility = View.VISIBLE
        binding.errorGroup.visibility = View.GONE
        player?.apply {
            stop()
            setMediaItem(MediaItem.fromUri(url))
            prepare()
            playWhenReady = true
        }
    }

    private fun openEmbed(url: String) {
        showLoader(false)
        // Intentar Chrome Custom Tab para URLs que no pudieron extraerse
        try {
            CustomTabsIntent.Builder()
                .setShowTitle(true)
                .build()
                .launchUrl(requireContext(), url.toUri())
        } catch (e: Exception) {
            binding.errorGroup.visibility = View.VISIBLE
            binding.tvPlayerError.text = "No se pudo abrir: $url"
        }
    }

    private fun buildServerChips(match: Match) {
        binding.chipGroupServers.removeAllViews()
        match.servers.forEachIndexed { i, srv ->
            val chip = Chip(requireContext()).apply {
                text = srv.name
                isCheckable = true
                isChecked = i == 0
                setOnCheckedChangeListener { _, checked -> if (checked) viewModel.switchServer(i) }
            }
            binding.chipGroupServers.addView(chip)
        }
    }

    private fun showLoader(show: Boolean) {
        binding.playerLoader.visibility = if (show) View.VISIBLE else View.GONE
    }

    private fun toggleFullscreen() {
        val isLandscape = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        requireActivity().requestedOrientation = if (isLandscape)
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
    }

    private fun enterFullscreen() {
        requireActivity().requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && viewModel.pipEnabled) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            requireActivity().enterPictureInPictureMode(params)
        } else {
            Toast.makeText(context, "PiP no disponible en este dispositivo", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onPause() {
        super.onPause()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) player?.pause()
    }

    override fun onStop() {
        super.onStop()
        if (!requireActivity().isInPictureInPictureMode) player?.pause()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        player?.release()
        player = null
        requireActivity().requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        _binding = null
    }
}
