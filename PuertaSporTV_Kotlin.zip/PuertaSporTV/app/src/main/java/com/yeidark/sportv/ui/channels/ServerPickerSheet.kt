package com.yeidark.sportv.ui.channels

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.os.bundleOf
import androidx.navigation.fragment.findNavController
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.button.MaterialButton
import com.yeidark.sportv.R
import com.yeidark.sportv.data.model.Channel
import com.yeidark.sportv.data.model.Match
import com.yeidark.sportv.data.model.Server

class ServerPickerSheet : BottomSheetDialogFragment() {

    companion object {
        private const val ARG_CHANNEL = "channel"

        fun newInstance(channel: Channel): ServerPickerSheet {
            return ServerPickerSheet().apply {
                arguments = bundleOf(ARG_CHANNEL to channel)
            }
        }

        fun newInstanceFromMatch(match: Match): ServerPickerSheet {
            // Convertir match a channel temporal para reutilizar la sheet
            val ch = Channel(
                name = match.name,
                logo = null,
                category = match.league,
                servers = match.servers
            )
            return newInstance(ch)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, saved: Bundle?): View {
        return inflater.inflate(R.layout.sheet_server_picker, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val channel = arguments?.getParcelable<Channel>(ARG_CHANNEL) ?: run {
            dismiss(); return
        }

        view.findViewById<TextView>(R.id.tvSheetTitle).text = channel.name
        val container = view.findViewById<LinearLayout>(R.id.serversContainer)

        channel.servers.forEach { server ->
            val btn = MaterialButton(requireContext()).apply {
                text = "▶  ${server.name}  [${server.quality}]"
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(0, 8, 0, 8) }
                setOnClickListener {
                    openPlayer(channel.name, server)
                    dismiss()
                }
            }
            container.addView(btn)
        }

        if (channel.servers.isEmpty()) {
            val tv = TextView(requireContext()).apply { text = "Sin servidores disponibles" }
            container.addView(tv)
        }
    }

    private fun openPlayer(title: String, server: Server) {
        try {
            val tempMatch = Match(
                id = title.hashCode().toString(),
                time = "", timeMin = 0,
                name = title, league = "", flag = "📺",
                servers = listOf(server)
            )
            findNavController().navigate(
                R.id.action_channels_to_player,
                bundleOf("matchJson" to tempMatch, "serverIndex" to 0)
            )
        } catch (e: Exception) {
            // Si no hay NavController disponible (sheet abierta desde agenda)
            dismiss()
        }
    }
}
