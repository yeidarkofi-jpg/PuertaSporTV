package com.yeidark.sportv.ui.channels

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.yeidark.sportv.R
import com.yeidark.sportv.data.model.Channel
import com.yeidark.sportv.data.model.ChannelsData
import com.yeidark.sportv.databinding.FragmentChannelsBinding
import com.yeidark.sportv.databinding.ItemChannelBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ChannelsFragment : Fragment() {

    private var _binding: FragmentChannelsBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, saved: Bundle?): View {
        _binding = FragmentChannelsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val spanCount = if (resources.configuration.screenWidthDp >= 600) 4 else 3
        binding.rvChannels.layoutManager = GridLayoutManager(requireContext(), spanCount)

        val adapter = ChannelAdapter { channel ->
            // Abrir bottom sheet de servidores
            ServerPickerSheet.newInstance(channel).show(parentFragmentManager, "servers")
        }
        binding.rvChannels.adapter = adapter
        adapter.submitList(ChannelsData.ALL)

        // Chips de categorías
        val categories = ChannelsData.ALL.map { it.category }.distinct().sorted()
        var selectedCat = "Todos"

        buildCategoryChips(categories, selectedCat) { cat ->
            selectedCat = cat
            val filtered = if (cat == "Todos") ChannelsData.ALL
                           else ChannelsData.ALL.filter { it.category == cat }
            adapter.submitList(filtered)
        }
    }

    private fun buildCategoryChips(
        categories: List<String>,
        selected: String,
        onSelect: (String) -> Unit
    ) {
        binding.chipGroupChannels.removeAllViews()
        val all = listOf("Todos") + categories
        all.forEach { cat ->
            val chip = com.google.android.material.chip.Chip(requireContext()).apply {
                text = cat
                isCheckable = true
                isChecked = cat == selected
                setOnCheckedChangeListener { _, checked -> if (checked) onSelect(cat) }
            }
            binding.chipGroupChannels.addView(chip)
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}

// ─── Adapter ─────────────────────────────────────────────────────────────────

class ChannelAdapter(
    private val onClick: (Channel) -> Unit
) : ListAdapter<Channel, ChannelAdapter.VH>(DIFF) {

    inner class VH(val b: ItemChannelBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(ch: Channel) {
            b.tvChannelName.text = ch.name
            b.tvServerCount.text = "${ch.servers.size} srv"
            if (!ch.logo.isNullOrBlank()) {
                Glide.with(b.ivLogo).load(ch.logo)
                    .placeholder(R.drawable.ic_tv)
                    .error(R.drawable.ic_tv)
                    .into(b.ivLogo)
            } else {
                b.ivLogo.setImageResource(R.drawable.ic_tv)
            }
            b.root.setOnClickListener { onClick(ch) }
            b.root.isFocusable = true
        }
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) = VH(
        ItemChannelBinding.inflate(LayoutInflater.from(p.context), p, false)
    )
    override fun onBindViewHolder(h: VH, pos: Int) = h.bind(getItem(pos))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Channel>() {
            override fun areItemsTheSame(a: Channel, b: Channel) = a.name == b.name
            override fun areContentsTheSame(a: Channel, b: Channel) = a == b
        }
    }
}
