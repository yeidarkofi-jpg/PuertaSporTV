package com.yeidark.sportv.ui.agenda

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.chip.Chip
import com.yeidark.sportv.R
import com.yeidark.sportv.databinding.FragmentAgendaBinding
import com.yeidark.sportv.util.TimeUtils
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class AgendaFragment : Fragment() {

    private var _binding: FragmentAgendaBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AgendaViewModel by viewModels()
    private lateinit var adapter: MatchAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, saved: Bundle?): View {
        _binding = FragmentAgendaBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = MatchAdapter(
            use12h = viewModel.use12h,
            onMatchClick = { match ->
                if (match.servers.isEmpty()) {
                    Toast.makeText(context, "Sin servidores disponibles", Toast.LENGTH_SHORT).show()
                    return@MatchAdapter
                }
                findNavController().navigate(
                    R.id.action_agenda_to_player,
                    bundleOf(
                        "matchJson" to match,
                        "serverIndex" to 0
                    )
                )
            }
        )

        binding.rvMatches.layoutManager = LinearLayoutManager(requireContext())
        binding.rvMatches.adapter = adapter
        binding.rvMatches.setHasFixedSize(true)

        binding.btnRefresh.setOnClickListener { viewModel.loadAgenda() }

        observeState()
    }

    private fun observeState() {
        lifecycleScope.launch {
            viewModel.state.collect { state ->
                when (state) {
                    is AgendaUiState.Loading -> {
                        binding.loader.visibility = View.VISIBLE
                        binding.rvMatches.visibility = View.GONE
                        binding.emptyState.visibility = View.GONE
                        binding.errorState.visibility = View.GONE
                    }
                    is AgendaUiState.Success -> {
                        binding.loader.visibility = View.GONE
                        binding.rvMatches.visibility = View.VISIBLE
                        binding.emptyState.visibility = View.GONE
                        binding.errorState.visibility = View.GONE
                        adapter.submitList(state.matches)
                        buildCategoryChips(state.categories)
                        binding.tvMatchCount.text = "${state.matches.size} partidos"
                    }
                    is AgendaUiState.Error -> {
                        binding.loader.visibility = View.GONE
                        binding.rvMatches.visibility = View.GONE
                        binding.emptyState.visibility = View.GONE
                        binding.errorState.visibility = View.VISIBLE
                        binding.tvError.text = state.message
                    }
                    is AgendaUiState.Empty -> {
                        binding.loader.visibility = View.GONE
                        binding.rvMatches.visibility = View.GONE
                        binding.emptyState.visibility = View.VISIBLE
                        binding.errorState.visibility = View.GONE
                    }
                }
            }
        }
    }

    private fun buildCategoryChips(categories: List<String>) {
        binding.chipGroupCategories.removeAllViews()
        categories.forEach { cat ->
            val chip = Chip(requireContext()).apply {
                text = cat
                isCheckable = true
                isChecked = cat == viewModel.selectedCategory.value
                setOnCheckedChangeListener { _, checked ->
                    if (checked) viewModel.selectCategory(cat)
                }
            }
            binding.chipGroupCategories.addView(chip)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
