package com.yeidark.sportv.ui.agenda

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.yeidark.sportv.data.model.Match
import com.yeidark.sportv.databinding.ItemMatchBinding
import com.yeidark.sportv.util.TimeUtils

class MatchAdapter(
    private val use12h: Boolean,
    private val onMatchClick: (Match) -> Unit
) : ListAdapter<Match, MatchAdapter.ViewHolder>(DIFF) {

    inner class ViewHolder(val binding: ItemMatchBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(match: Match) {
            binding.tvFlag.text = match.flag
            binding.tvTime.text = TimeUtils.formatTime(match.time, use12h)
            binding.tvName.text = match.name
            binding.tvLeague.text = match.league
            val srvCount = match.servers.size
            binding.tvServers.text = when {
                srvCount == 0 -> "Sin señal"
                srvCount == 1 -> "1 servidor"
                else -> "$srvCount servidores"
            }
            binding.root.setOnClickListener { onMatchClick(match) }
            binding.root.isFocusable = true
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemMatchBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Match>() {
            override fun areItemsTheSame(a: Match, b: Match) = a.id == b.id
            override fun areContentsTheSame(a: Match, b: Match) = a == b
        }
    }
}
