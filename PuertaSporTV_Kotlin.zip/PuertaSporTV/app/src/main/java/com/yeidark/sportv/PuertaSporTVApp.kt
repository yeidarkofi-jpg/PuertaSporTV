package com.yeidark.sportv

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class PuertaSporTVApp : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)

            // Canal de partidos favoritos
            val matchChannel = NotificationChannel(
                CHANNEL_MATCHES,
                "Partidos Favoritos",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Avisos de partidos de tus equipos favoritos"
                enableVibration(true)
            }

            // Canal de reproducción
            val playerChannel = NotificationChannel(
                CHANNEL_PLAYER,
                "Reproductor",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Controles de reproducción"
            }

            manager.createNotificationChannels(listOf(matchChannel, playerChannel))
        }
    }

    companion object {
        const val CHANNEL_MATCHES = "pstv_matches"
        const val CHANNEL_PLAYER  = "pstv_player"
    }
}
