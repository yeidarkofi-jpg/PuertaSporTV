package com.yeidark.sportv.data.repository

import com.yeidark.sportv.data.model.AgendaSource
import com.yeidark.sportv.data.model.Match
import com.yeidark.sportv.data.remote.parser.AgendaEventParser
import com.yeidark.sportv.data.remote.parser.AgendaS1Parser
import com.yeidark.sportv.data.remote.parser.AgendaTableParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AgendaRepository @Inject constructor(
    private val okHttpClient: OkHttpClient
) {
    suspend fun fetchAgenda(useStock: Boolean = false): List<Match> = withContext(Dispatchers.IO) {
        if (useStock) return@withContext fetchStock()

        // Intentar S1, S2, S3 en orden
        val sources = listOf(
            AgendaSource.S1 to "S1",
            AgendaSource.S2 to "S2",
            AgendaSource.S3_A to "S3",
            AgendaSource.S3_B to "S3b"
        )
        for ((source, name) in sources) {
            try {
                val html = fetchHtml(source.url)
                if (html.length < 500) continue
                val matches = when (source) {
                    AgendaSource.S1   -> AgendaS1Parser.parse(html)
                    AgendaSource.S2   -> AgendaEventParser.parse(html, "https://streamtp10.com")
                    AgendaSource.S3_A, AgendaSource.S3_B -> AgendaEventParser.parse(html, "https://la14hd.com")
                    else -> emptyList()
                }
                if (matches.isNotEmpty()) return@withContext matches
            } catch (e: Exception) {
                // Continuar al siguiente
            }
        }
        emptyList()
    }

    private suspend fun fetchStock(): List<Match> = withContext(Dispatchers.IO) {
        try {
            val html = fetchHtml(AgendaSource.STOCK.url)
            val doc = Jsoup.parse(html)
            AgendaTableParser.parse(doc, "https://www.lapelotona.com")
        } catch (e: Exception) { emptyList() }
    }

    private fun fetchHtml(url: String): String {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Android 14; Mobile) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36")
            .header("Accept", "text/html,application/xhtml+xml")
            .header("Accept-Language", "es-419,es;q=0.9")
            .build()
        return okHttpClient.newCall(request).execute().use { it.body?.string() ?: "" }
    }
}

@Singleton
class StreamExtractor @Inject constructor(
    private val okHttpClient: OkHttpClient
) {
    private val HLS_PATTERNS = listOf(
        Regex("""['"]([^'"]+\.m3u8[^'"]*)['"]"""),
        Regex("""source\s*:\s*['"]([^'"]+\.m3u8[^'"]*)['"]"""),
        Regex("""file\s*:\s*['"]([^'"]+\.m3u8[^'"]*)['"]"""),
        Regex("""src\s*=\s*['"]([^'"]+\.m3u8[^'"]*)['"]"""),
        Regex("""url\s*:\s*['"]([^'"]+\.m3u8[^'"]*)['"]"""),
        Regex("""['"]([^'"]+\.mpd[^'"]*)['"]"""),  // DASH
    )

    private val DIRECT_EXTENSIONS = listOf(".m3u8", ".mpd", ".mp4", ".ts")

    sealed class Result {
        data class Direct(val streamUrl: String) : Result()
        data class Embed(val embedUrl: String) : Result()
        data class Error(val msg: String) : Result()
    }

    suspend fun resolve(url: String): Result = withContext(Dispatchers.IO) {
        // Ya es un stream directo
        if (DIRECT_EXTENSIONS.any { url.lowercase().contains(it) }) {
            return@withContext Result.Direct(url)
        }

        // Intentar extraer HLS de la página embed
        try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Android 14; Mobile) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36")
                .header("Referer", "https://embed.ksdjugfsddeports.com/")
                .header("Origin", "https://embed.ksdjugfsddeports.com")
                .build()
            val html = okHttpClient.newCall(request).execute().use { it.body?.string() ?: "" }

            for (pattern in HLS_PATTERNS) {
                val match = pattern.find(html)
                if (match != null) {
                    val streamUrl = match.groupValues[1]
                    if (streamUrl.startsWith("http") || streamUrl.startsWith("//")) {
                        val resolved = if (streamUrl.startsWith("//")) "https:$streamUrl" else streamUrl
                        return@withContext Result.Direct(resolved)
                    }
                }
            }

            // Buscar iframes anidados con stream
            val iframeSrc = Regex("""<iframe[^>]+src=['"]([^'"]+)['"]""").find(html)
            if (iframeSrc != null) {
                val iUrl = iframeSrc.groupValues[1]
                if (iUrl.startsWith("http") && iUrl != url) {
                    return@withContext resolve(iUrl)  // recursivo una vez
                }
            }
        } catch (e: Exception) {
            // fall through to embed
        }

        // No se pudo extraer → abrir como embed (Chrome Custom Tab)
        Result.Embed(url)
    }
}
