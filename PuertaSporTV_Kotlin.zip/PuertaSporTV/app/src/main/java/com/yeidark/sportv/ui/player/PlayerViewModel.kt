package com.yeidark.sportv.ui.player

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.yeidark.sportv.data.model.Match
import com.yeidark.sportv.data.model.Server
import com.yeidark.sportv.data.repository.StreamExtractor
import com.yeidark.sportv.util.PreferencesManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class StreamState {
    object Idle : StreamState()
    object Loading : StreamState()
    data class Direct(val hlsUrl: String) : StreamState()
    data class Embed(val embedUrl: String) : StreamState()
    data class Error(val msg: String) : StreamState()
}

@HiltViewModel
class PlayerViewModel @Inject constructor(
    private val extractor: StreamExtractor,
    private val prefs: PreferencesManager
) : ViewModel() {

    private val _streamState = MutableStateFlow<StreamState>(StreamState.Idle)
    val streamState: StateFlow<StreamState> = _streamState.asStateFlow()

    private val _currentServerIndex = MutableStateFlow(0)
    val currentServerIndex: StateFlow<Int> = _currentServerIndex.asStateFlow()

    var match: Match? = null
    val pipEnabled get() = prefs.getBool(PreferencesManager.KEY_PIP, true)
    val autoFullscreen get() = prefs.getBool(PreferencesManager.KEY_AUTO_FS, false)

    fun loadMatch(m: Match, serverIndex: Int = 0) {
        match = m
        _currentServerIndex.value = serverIndex
        resolveServer(m.servers.getOrNull(serverIndex) ?: return)
    }

    fun switchServer(index: Int) {
        val m = match ?: return
        val server = m.servers.getOrNull(index) ?: return
        _currentServerIndex.value = index
        resolveServer(server)
    }

    private fun resolveServer(server: Server) {
        viewModelScope.launch {
            _streamState.value = StreamState.Loading
            when (val result = extractor.resolve(server.url)) {
                is StreamExtractor.Result.Direct -> _streamState.value = StreamState.Direct(result.streamUrl)
                is StreamExtractor.Result.Embed  -> _streamState.value = StreamState.Embed(result.embedUrl)
                is StreamExtractor.Result.Error  -> _streamState.value = StreamState.Error(result.msg)
            }
        }
    }

    fun retry() {
        val m = match ?: return
        resolveServer(m.servers.getOrNull(_currentServerIndex.value) ?: return)
    }
}
