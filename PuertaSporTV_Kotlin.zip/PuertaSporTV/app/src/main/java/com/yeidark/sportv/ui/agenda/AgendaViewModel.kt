package com.yeidark.sportv.ui.agenda

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.yeidark.sportv.data.model.Match
import com.yeidark.sportv.data.repository.AgendaRepository
import com.yeidark.sportv.util.PreferencesManager
import com.yeidark.sportv.util.TimeUtils
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class AgendaUiState {
    object Loading : AgendaUiState()
    data class Success(val matches: List<Match>, val categories: List<String>) : AgendaUiState()
    data class Error(val message: String) : AgendaUiState()
    object Empty : AgendaUiState()
}

@HiltViewModel
class AgendaViewModel @Inject constructor(
    private val repository: AgendaRepository,
    private val prefs: PreferencesManager
) : ViewModel() {

    private val _state = MutableStateFlow<AgendaUiState>(AgendaUiState.Loading)
    val state: StateFlow<AgendaUiState> = _state.asStateFlow()

    private val _selectedCategory = MutableStateFlow("Todos")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private var allMatches: List<Match> = emptyList()
    val use12h get() = prefs.getBool(PreferencesManager.KEY_12H, false)
    val useStock get() = prefs.getBool(PreferencesManager.KEY_STOCK, false)

    init { loadAgenda() }

    fun loadAgenda() {
        viewModelScope.launch {
            _state.value = AgendaUiState.Loading
            try {
                val matches = repository.fetchAgenda(useStock)
                val filtered = TimeUtils.filterFinished(matches)
                allMatches = filtered
                val cats = buildCategories(filtered)
                _state.value = if (filtered.isEmpty()) AgendaUiState.Empty
                else AgendaUiState.Success(applyFilter(filtered), cats)
            } catch (e: Exception) {
                _state.value = AgendaUiState.Error(e.message ?: "Error de conexión")
            }
        }
    }

    fun selectCategory(cat: String) {
        _selectedCategory.value = cat
        val cur = _state.value
        if (cur is AgendaUiState.Success) {
            _state.value = cur.copy(matches = applyFilter(allMatches))
        }
    }

    private fun applyFilter(matches: List<Match>): List<Match> {
        val cat = _selectedCategory.value
        return if (cat == "Todos") matches
        else matches.filter { it.flag == cat || it.league.contains(cat, true) }
    }

    private fun buildCategories(matches: List<Match>): List<String> {
        val cats = mutableListOf("Todos")
        cats += matches.map { it.league }.distinct().sorted()
        return cats
    }
}
