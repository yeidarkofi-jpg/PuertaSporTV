package com.yeidark.sportv.ui.common

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.yeidark.sportv.PuertaSporTVApp
import com.yeidark.sportv.R
import com.yeidark.sportv.ui.MainActivity
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.concurrent.TimeUnit

@HiltWorker
class MatchNotificationWorker @AssistedInject constructor(
    @Assisted ctx: Context,
    @Assisted params: WorkerParameters
) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val title  = inputData.getString("title")  ?: return Result.failure()
        val body   = inputData.getString("body")   ?: return Result.failure()

        val intent = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pi = PendingIntent.getActivity(
            applicationContext, title.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(
            applicationContext, PuertaSporTVApp.CHANNEL_MATCHES
        )
            .setSmallIcon(R.drawable.ic_ball)
            .setContentTitle(title)
            .setContentText(body)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        val manager = applicationContext.getSystemService(NotificationManager::class.java)
        manager.notify(title.hashCode(), notification)
        return Result.success()
    }

    companion object {
        fun schedule(context: Context, matchId: String, title: String, league: String, delayMs: Long) {
            if (delayMs <= 0) return
            val data = workDataOf(
                "title" to "⚽ $title",
                "body"  to "Partido por comenzar · $league"
            )
            val request = OneTimeWorkRequestBuilder<MatchNotificationWorker>()
                .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
                .setInputData(data)
                .addTag(matchId)
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                matchId, ExistingWorkPolicy.REPLACE, request
            )
        }

        fun cancel(context: Context, matchId: String) {
            WorkManager.getInstance(context).cancelUniqueWork(matchId)
        }
    }
}
