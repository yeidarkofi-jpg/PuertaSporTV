package com.yeidark.sportv.data.remote.parser

import com.yeidark.sportv.data.model.Match
import com.yeidark.sportv.data.model.Server
import com.yeidark.sportv.util.LeagueFlags
import com.yeidark.sportv.util.TimeUtils
import org.jsoup.Jsoup
import org.jsoup.nodes.Document

// ─── Utilidades compartidas ───────────────────────────────────────────────────

private fun String.splitLeagueName(): Pair<String, String> {
    val ci = indexOf(':')
    return if (ci != -1 && ci < 80) {
        substring(0, ci).trim() to substring(ci + 1).trim()
    } else {
        "Partido" to trim()
    }
}

private fun parseTimeToMin(t: String): Int? {
    // 12h: "8:30 pm"
    val m12 = Regex("""(\d{1,2}):(\d{2})\s*(am|pm)""", RegexOption.IGNORE_CASE).find(t)
    if (m12 != null) {
        var h = m12.groupValues[1].toInt()
        val m = m12.groupValues[2].toInt()
        val pm = m12.groupValues[3].lowercase() == "pm"
        if (pm && h != 12) h += 12
        if (!pm && h == 12) h = 0
        return h * 60 + m
    }
    // 24h: "14:30"
    val m24 = Regex("""(\d{1,2}):(\d{2})""").find(t)
    if (m24 != null) {
        val h = m24.groupValues[1].toInt()
        val m = m24.groupValues[2].toInt()
        if (h in 0..23 && m in 0..59) return h * 60 + m
    }
    return null
}

private fun toDisplayTime(raw: String): Pair<String, Int> {
    val min = parseTimeToMin(raw) ?: return raw to 0
    val h = min / 60; val m = min % 60
    val display = "L:" + h.toString().padStart(2, '0') + ":" + m.toString().padStart(2, '0')
    return display to min
}

private fun makeId(time: String, name: String) = (time + name).hashCode().toString()

// ─── Parser S1: librefutboltv.su ─────────────────────────────────────────────
object AgendaS1Parser {
    fun parse(html: String): List<Match> {
        val doc = Jsoup.parse(html)
        return doc.select("li").mapNotNull { li ->
            val cu = li.selectFirst(":root > ul") ?: return@mapNotNull null
            val ml = li.selectFirst(":root > a") ?: return@mapNotNull null
            val raw = ml.text().trim()
            if (raw.length < 5) return@mapNotNull null

            val timeMatch = Regex("""(\d{1,2}:\d{2})$""").find(raw)
            val rawTime = timeMatch?.value ?: ""
            val full = raw.removeSuffix(rawTime).trim()
            val (league, name) = full.splitLeagueName()
            if (name.length < 2) return@mapNotNull null

            val (displayTime, timeMin) = if (rawTime.isNotEmpty()) toDisplayTime(rawTime) else "" to 0

            val servers = cu.select("li > a").mapNotNull { sa ->
                val href = sa.attr("href").trim()
                val sname = sa.text().trim().replace(Regex("Calidad\\s+\\S+", RegexOption.IGNORE_CASE), "").trim()
                val url = resolveUrl(href) ?: return@mapNotNull null
                Server(sname.ifEmpty { "Servidor" }, "HD", url)
            }

            Match(
                id = makeId(displayTime, name),
                time = displayTime, timeMin = timeMin,
                name = name, league = league.ifEmpty { "Partido" },
                flag = LeagueFlags.get(league.ifEmpty { name }),
                servers = servers
            )
        }.filter { it.name.length > 2 }
    }

    private fun resolveUrl(href: String): String? {
        if (href.isBlank() || href == "#") return null
        return if (href.startsWith("http")) href
        else "https://librefutboltv.su$href"
    }
}

// ─── Parser S2/S3: streamtp10 y la14hd (div.event) ──────────────────────────
object AgendaEventParser {
    fun parse(html: String, base: String): List<Match> {
        val doc = Jsoup.parse(html)
        val result = mutableListOf<Match>()
        val seen = mutableMapOf<String, Int>()

        doc.select("div.event, .event").forEach { ev ->
            val nameEl = ev.selectFirst("p.event-name, .event-name, p") ?: return@forEach
            val rawName = nameEl.text().replace(Regex("\\s+"), " ").trim()

            val tmM = Regex("""(\d{1,2}:\d{2})""").find(rawName) ?: return@forEach
            if (!rawName.contains(Regex("\\bvs\\b", RegexOption.IGNORE_CASE))) return@forEach

            val rawTime = tmM.value
            val timeMin = parseTimeToMin(rawTime) ?: return@forEach
            val h = timeMin / 60; val m = timeMin % 60
            val displayTime = "L:" + h.toString().padStart(2,'0') + ":" + m.toString().padStart(2,'0')

            var raw = rawName.replace(Regex("""^\s*\d{1,2}:\d{2}\s*[-–]?\s*"""), "").trim()
            var league = "Partido"; var name = raw
            val ci = raw.indexOf(':')
            if (ci in 1..69) {
                val pL = raw.substring(0, ci).trim()
                val pN = raw.substring(ci + 1).trim()
                if (pN.contains(Regex("\\bvs\\b", RegexOption.IGNORE_CASE)) && pL.length in 2..69) {
                    league = pL; name = pN
                }
            }
            name = name.replace(Regex("\\s+"), " ").trim()
            if (name.length < 5) return@forEach

            val inp = ev.selectFirst("input.iframe-link, input[value]")
            var url = inp?.attr("value")?.trim() ?: ""
            if (url.isEmpty() || !url.startsWith("http")) {
                val a = ev.selectFirst("a.copy-button, a[href*=stream]")
                url = a?.attr("href")?.trim() ?: ""
            }
            if (url.isEmpty() || !url.startsWith("http")) return@forEach

            val sp = Regex("""[?&]stream=([^&\s#]+)""").find(url)
            val srvName = sp?.groupValues?.get(1)?.replace("_"," ")?.uppercase()
                ?: url.split("/").last().split("?").first().uppercase().ifEmpty { "Canal" }

            val key = "$displayTime|${name.take(35).lowercase().replace(Regex("\\s+"),"")}"
            val idx = seen[key]
            if (idx != null) {
                if (result[idx].servers.none { it.url == url })
                    (result[idx].servers as MutableList).add(Server(srvName, "HD", url))
            } else {
                seen[key] = result.size
                result.add(Match(
                    id = makeId(displayTime, name), time = displayTime, timeMin = timeMin,
                    name = name, league = league, flag = LeagueFlags.get(league),
                    servers = mutableListOf(Server(srvName, "HD", url))
                ))
            }
        }

        return if (result.isNotEmpty()) result.sortedBy { it.timeMin }
        else AgendaTableParser.parse(doc, base)
    }
}

// ─── Parser Stock: lapelotona.com (tablas HTML) ──────────────────────────────
object AgendaTableParser {
    fun parse(doc: Document, base: String): List<Match> {
        val result = mutableListOf<Match>()
        val seen = mutableSetOf<String>()

        doc.select("table tr").forEach { row ->
            val tds = row.select("td")
            if (tds.size < 2) return@forEach

            val teamsRaw = tds[0].text().trim()
            val teamLines = teamsRaw.split("\n").map { it.trim() }.filter { it.length > 1 }
            if (teamLines.size < 2) return@forEach
            val matchName = "${teamLines[0]} vs ${teamLines[1]}"

            val infoRaw = tds[1].text().replace(Regex("\\s+"), " ").trim()
            val timeM = Regex("""(\d{1,2}:\d{2}\s*(?:am|pm))""", RegexOption.IGNORE_CASE).find(infoRaw)
                ?: return@forEach
            val rawTime = timeM.value.trim()
            val (displayTime, timeMin) = toDisplayTime(rawTime)

            val dashIdx = infoRaw.indexOf(" - ")
            val league = if (dashIdx > 0) {
                val after = infoRaw.substring(infoRaw.indexOf(rawTime) + rawTime.length).trim()
                after.split(" - ").getOrNull(0)?.trim()?.ifEmpty { "Partido" } ?: "Partido"
            } else "Partido"
            val chansText = if (dashIdx > 0) infoRaw.substringAfter(" - ").substringAfter(" - ") else ""

            val key = displayTime + matchName
            if (seen.contains(key)) return@forEach
            seen.add(key)

            val combinedText = "$league $matchName".lowercase()
            if (combinedText.contains("femenin") || combinedText.contains("women")) return@forEach

            val servers = findChannelsForText(chansText)
            result.add(Match(
                id = makeId(displayTime, matchName), time = displayTime, timeMin = timeMin,
                name = matchName, league = league, flag = LeagueFlags.get(league),
                servers = servers
            ))
        }

        return result.sortedBy { it.timeMin }
    }

    private fun findChannelsForText(text: String): List<Server> {
        val q = text.lowercase()
        val found = mutableListOf<Server>()
        val seen = mutableSetOf<String>()
        for ((key, names) in com.yeidark.sportv.data.model.ChannelsData.CHAN_MAP) {
            if (q.contains(key)) {
                for (name in names) {
                    if (seen.contains(name)) continue
                    val ch = com.yeidark.sportv.data.model.ChannelsData.ALL.find { it.name == name }
                    if (ch != null) {
                        ch.servers.forEach { s ->
                            found.add(Server("${ch.name} · ${s.name}", s.quality, s.url))
                        }
                        seen.add(name)
                    }
                }
            }
        }
        return found
    }
}
