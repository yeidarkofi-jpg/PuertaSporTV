package com.yeidark.sportv.ui.settings

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.android.material.chip.Chip
import com.yeidark.sportv.databinding.FragmentSettingsBinding
import com.yeidark.sportv.util.PreferencesManager
import com.yeidark.sportv.util.ThemeManager
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    @Inject lateinit var prefs: PreferencesManager

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, saved: Bundle?): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Cargar valores actuales
        val currentTheme = prefs.get(PreferencesManager.KEY_THEME, "azul")
        val is12h = prefs.getBool(PreferencesManager.KEY_12H, false)
        val isPip  = prefs.getBool(PreferencesManager.KEY_PIP, true)
        val isStock = prefs.getBool(PreferencesManager.KEY_STOCK, false)
        val isSrcLock = prefs.getBool(PreferencesManager.KEY_SRCLOCK, false)
        val isAutoFs = prefs.getBool(PreferencesManager.KEY_AUTO_FS, false)

        // Temas
        buildThemeChips(currentTheme)

        // Switches
        binding.switch12h.isChecked = is12h
        binding.switchPip.isChecked = isPip
        binding.switchStock.isChecked = isStock
        binding.switchSrcLock.isChecked = isSrcLock
        binding.switchAutoFs.isChecked = isAutoFs

        binding.switch12h.setOnCheckedChangeListener { _, v ->
            prefs.setBool(PreferencesManager.KEY_12H, v)
            toast(if (v) "Formato 12h (AM/PM)" else "Formato 24h")
        }
        binding.switchPip.setOnCheckedChangeListener { _, v ->
            prefs.setBool(PreferencesManager.KEY_PIP, v)
            toast(if (v) "PiP activado" else "PiP desactivado")
        }
        binding.switchStock.setOnCheckedChangeListener { _, v ->
            prefs.setBool(PreferencesManager.KEY_STOCK, v)
            toast(if (v) "Modo Stock (La Pelotona)" else "Modo Agenda normal")
        }
        binding.switchSrcLock.setOnCheckedChangeListener { _, v ->
            prefs.setBool(PreferencesManager.KEY_SRCLOCK, v)
            toast(if (v) "Fuente bloqueada" else "Fuente libre")
        }
        binding.switchAutoFs.setOnCheckedChangeListener { _, v ->
            prefs.setBool(PreferencesManager.KEY_AUTO_FS, v)
            toast(if (v) "Pantalla completa automática ON" else "Pantalla completa automática OFF")
        }

        // Tamaño de fuente
        val fontSize = prefs.getInt(PreferencesManager.KEY_FONT, 2)
        binding.seekFontSize.progress = fontSize
        binding.seekFontSize.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: android.widget.SeekBar?, p: Int, f: Boolean) {
                prefs.setInt(PreferencesManager.KEY_FONT, p)
            }
            override fun onStartTrackingTouch(s: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(s: android.widget.SeekBar?) {}
        })

        // Info versión
        val versionName = try {
            requireContext().packageManager.getPackageInfo(requireContext().packageName, 0).versionName
        } catch (e: Exception) { "1.0.0" }
        binding.tvVersion.text = "Puerta SporTV v$versionName"
    }

    private fun buildThemeChips(current: String) {
        binding.chipGroupThemes.removeAllViews()
        ThemeManager.THEMES.keys.forEach { key ->
            val icon = ThemeManager.THEME_ICONS[key] ?: ""
            val name = ThemeManager.THEME_NAMES[key] ?: key
            val chip = Chip(requireContext()).apply {
                text = "$icon $name"
                isCheckable = true
                isChecked = key == current
                setOnCheckedChangeListener { _, checked ->
                    if (checked) applyTheme(key)
                }
            }
            binding.chipGroupThemes.addView(chip)
        }
    }

    private fun applyTheme(themeName: String) {
        prefs.set(PreferencesManager.KEY_THEME, themeName)
        toast("Tema ${ThemeManager.THEME_NAMES[themeName]} aplicado — reiniciando…")
        requireActivity().recreate()
    }

    private fun toast(msg: String) {
        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
