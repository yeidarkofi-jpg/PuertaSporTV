package com.yeidark.sportv.data.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Match(
    val id: String,
    val time: String,        // "L:HH:MM" (sitio UTC+1) o "HH:MM"
    val timeMin: Int,        // minutos desde medianoche para ordenar
    val name: String,        // "Real Madrid vs Barcelona"
    val league: String,
    val flag: String,        // emoji bandera
    val servers: List<Server>
) : Parcelable

@Parcelize
data class Server(
    val name: String,
    val quality: String,
    val url: String
) : Parcelable

@Parcelize
data class Channel(
    val name: String,
    val logo: String?,
    val category: String,
    val servers: List<Server>
) : Parcelable

enum class AgendaSource(val url: String) {
    S1("https://librefutboltv.su/home1/agenda/"),
    S2("https://streamtp10.com/eventos.html"),
    S3_A("https://la14hd.com/eventos/"),
    S3_B("https://la14hd.com//eventos/"),
    STOCK("https://www.lapelotona.com/partidos-de-futbol-para-hoy-en-vivo/")
}
