package com.yeidark.sportv.ui.common

import android.content.Context
import android.util.Log
import com.google.android.play.core.integrity.IntegrityManagerFactory
import com.google.android.play.core.integrity.IntegrityTokenRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object PlayIntegrityChecker {

    private const val TAG = "PlayIntegrity"

    // Tu PROJECT_NUMBER de Google Cloud Console (reemplazar en producción)
    private const val CLOUD_PROJECT_NUMBER = 123456789L

    suspend fun check(context: Context): IntegrityResult = withContext(Dispatchers.IO) {
        try {
            val manager = IntegrityManagerFactory.create(context)
            val nonce = generateNonce()
            val tokenResult = suspendCancellableCoroutine { cont ->
                manager.requestIntegrityToken(
                    IntegrityTokenRequest.builder()
                        .setCloudProjectNumber(CLOUD_PROJECT_NUMBER)
                        .setNonce(nonce)
                        .build()
                ).addOnSuccessListener { result ->
                    cont.resume(result)
                }.addOnFailureListener { e ->
                    cont.resumeWithException(e)
                }
            }
            // En producción: enviar tokenResult.token() a tu backend para verificación
            Log.d(TAG, "Token obtenido: ${tokenResult.token().take(30)}...")
            IntegrityResult.Ok
        } catch (e: Exception) {
            Log.w(TAG, "Play Integrity no disponible: ${e.message}")
            // En debug / sideload: permitir ejecución de todas formas
            IntegrityResult.Skipped(e.message ?: "No disponible")
        }
    }

    private fun generateNonce(): String {
        val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
        return (1..50).map { chars.random() }.joinToString("")
    }

    sealed class IntegrityResult {
        object Ok : IntegrityResult()
        data class Failed(val reason: String) : IntegrityResult()
        data class Skipped(val reason: String) : IntegrityResult()
    }
}
