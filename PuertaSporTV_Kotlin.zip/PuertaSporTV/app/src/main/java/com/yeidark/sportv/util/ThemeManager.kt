package com.yeidark.sportv.util

import android.app.Activity
import com.yeidark.sportv.R

object ThemeManager {
    val THEMES = mapOf(
        "azul"    to R.style.Theme_PuertaSporTV_Azul,
        "verde"   to R.style.Theme_PuertaSporTV_Verde,
        "rojo"    to R.style.Theme_PuertaSporTV_Rojo,
        "morado"  to R.style.Theme_PuertaSporTV_Morado,
        "naranja" to R.style.Theme_PuertaSporTV_Naranja,
        "cian"    to R.style.Theme_PuertaSporTV_Cian,
        "rosa"    to R.style.Theme_PuertaSporTV_Rosa,
        "dorado"  to R.style.Theme_PuertaSporTV_Dorado,
        "amoled"  to R.style.Theme_PuertaSporTV_Amoled,
        "claro"   to R.style.Theme_PuertaSporTV_Claro,
    )

    val THEME_NAMES = mapOf(
        "azul"    to "Azul",
        "verde"   to "Verde",
        "rojo"    to "Rojo",
        "morado"  to "Morado",
        "naranja" to "Naranja",
        "cian"    to "Cian",
        "rosa"    to "Rosa",
        "dorado"  to "Dorado",
        "amoled"  to "AMOLED",
        "claro"   to "Claro",
    )

    val THEME_ICONS = mapOf(
        "azul"    to "🔵",
        "verde"   to "🟢",
        "rojo"    to "🔴",
        "morado"  to "🟣",
        "naranja" to "🟠",
        "cian"    to "🩵",
        "rosa"    to "🩷",
        "dorado"  to "🟡",
        "amoled"  to "⚫",
        "claro"   to "⚪",
    )

    fun apply(activity: Activity, themeName: String) {
        val themeRes = THEMES[themeName] ?: R.style.Theme_PuertaSporTV_Azul
        activity.setTheme(themeRes)
    }
}
