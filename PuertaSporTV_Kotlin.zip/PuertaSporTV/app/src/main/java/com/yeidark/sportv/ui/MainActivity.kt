package com.yeidark.sportv.ui

import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.yeidark.sportv.R
import com.yeidark.sportv.databinding.ActivityMainBinding
import com.yeidark.sportv.util.PreferencesManager
import com.yeidark.sportv.util.ThemeManager
import com.yeidark.sportv.util.TvModeManager
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    @Inject lateinit var prefs: PreferencesManager

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        // Aplicar tema guardado ANTES de setContentView
        val savedTheme = prefs.get(PreferencesManager.KEY_THEME, "azul")
        ThemeManager.apply(this, savedTheme)

        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.navHostFragment) as NavHostFragment
        val navController = navHostFragment.navController

        binding.bottomNav.setupWithNavController(navController)

        // Modo TV: ocultar bottom nav en pantalla de player
        navController.addOnDestinationChangedListener { _, dest, _ ->
            val isPlayer = dest.id == R.id.playerFragment
            binding.bottomNav.visibility = if (isPlayer) View.GONE else View.VISIBLE
        }

        // Configurar modo TV si aplica
        if (TvModeManager.isTV(this)) {
            binding.bottomNav.visibility = View.GONE
        }
    }

    // Propagar eventos D-pad al fragment activo
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return super.onKeyDown(keyCode, event)
    }
}
