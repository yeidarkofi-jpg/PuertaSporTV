package com.yeidark.sportv.util

import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration

object TvModeManager {
    fun isAndroidTV(context: Context): Boolean {
        val uiModeManager = context.getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
        return uiModeManager.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION
    }

    fun isTV(context: Context): Boolean {
        if (isAndroidTV(context)) return true
        val noTouch = !context.packageManager.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN)
        val cfg = context.resources.configuration
        val bigScreen = cfg.screenWidthDp >= 960
        return noTouch && bigScreen
    }
}
