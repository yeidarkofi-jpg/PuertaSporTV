package com.yeidark.sportv.util

import android.content.Context
import android.content.SharedPreferences
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PreferencesManager @Inject constructor(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("pstv_prefs", Context.MODE_PRIVATE)

    fun get(key: String, default: String = "") = prefs.getString(key, default) ?: default
    fun set(key: String, value: String) = prefs.edit().putString(key, value).apply()
    fun getBool(key: String, default: Boolean = false) = prefs.getBoolean(key, default)
    fun setBool(key: String, value: Boolean) = prefs.edit().putBoolean(key, value).apply()
    fun getInt(key: String, default: Int = 0) = prefs.getInt(key, default)
    fun setInt(key: String, value: Int) = prefs.edit().putInt(key, value).apply()

    companion object {
        const val KEY_THEME         = "pstv_t"
        const val KEY_FONT          = "pstv_f"
        const val KEY_12H           = "pstv_12h"
        const val KEY_SRCLOCK       = "pstv_srclock"
        const val KEY_PIP           = "pstv_pip"
        const val KEY_STOCK         = "pstv_stock"
        const val KEY_FAVS          = "pstv_favs"
        const val KEY_FAV_LEAGUES   = "pstv_favleagues"
        const val KEY_DEVICE        = "pstv_d"
        const val KEY_AUTO_FS       = "pstv_auto_fs"
    }
}

object TimeUtils {
    // UTC+1 (España invierno). Ajustar a +2 en verano si es necesario.
    private const val SITE_OFFSET_HOURS = 1

    /**
     * Convierte un tiempo de la agenda al formato local del dispositivo.
     * Soporta "L:HH:MM" (hora del sitio UTC+1) y "HH:MM" (24h directo).
     */
    fun formatTime(raw: String, use12h: Boolean = false): String {
        if (raw.isBlank()) return ""
        val rawTime = if (raw.startsWith("L:")) raw.substring(2) else raw
        val parts = rawTime.split(":")
        val h = parts.getOrNull(0)?.toIntOrNull() ?: return raw
        val m = parts.getOrNull(1)?.toIntOrNull() ?: 0

        val siteOffsetMin = SITE_OFFSET_HOURS * 60
        val tz = java.util.TimeZone.getDefault()
        val now = java.util.Date()
        val localOffsetMin = (tz.getOffset(now.time)) / 60000

        val utcMin = h * 60 + m - siteOffsetMin
        val localMin = ((utcMin + localOffsetMin) % 1440 + 1440) % 1440
        val lh = localMin / 60
        val lm = localMin % 60
        val mm = lm.toString().padStart(2, '0')

        return if (use12h) {
            val ampm = if (lh >= 12) "PM" else "AM"
            val h12 = (lh % 12).let { if (it == 0) 12 else it }
            "$h12:$mm $ampm"
        } else {
            "$lh:$mm"
        }
    }

    fun filterFinished(matches: List<com.yeidark.sportv.data.model.Match>): List<com.yeidark.sportv.data.model.Match> {
        val cal = java.util.Calendar.getInstance()
        val nowMin = cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE)
        return matches.filter { m ->
            val endMin = m.timeMin + 105
            val nowAdj = if (endMin >= 1440 && nowMin < 360) nowMin + 1440 else nowMin
            nowAdj < endMin
        }
    }
}

object LeagueFlags {
    private val FLAGS = mapOf(
        "liga mx" to "🇲🇽", "liga betplay" to "🇨🇴", "liga de primera" to "🇨🇱",
        "copa libertadores" to "🏆", "copa sudamericana" to "🌎",
        "champions" to "🏆", "liga pro" to "🇪🇨",
        "premier" to "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "laliga" to "🇪🇸", "la liga" to "🇪🇸",
        "bundesliga" to "🇩🇪", "serie a" to "🇮🇹", "ligue 1" to "🇫🇷",
        "mls" to "🇺🇸", "primera división" to "🇦🇷", "liga profesional" to "🇦🇷",
        "dimayor" to "🇨🇴", "ligapro" to "🇪🇨", "eredivisie" to "🇳🇱",
        "primeira liga" to "🇵🇹", "superliga" to "🇦🇷"
    )

    fun get(text: String): String {
        if (text.isBlank()) return "⚽"
        val l = text.lowercase()
        for ((k, v) in FLAGS) if (l.contains(k)) return v
        return "⚽"
    }
}
